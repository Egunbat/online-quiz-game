import React, { useState, useEffect } from 'react';
import { useSocket } from '../contexts/SocketContext';
import LoginModal from './LoginModal';
import './Home.css';

function Home() {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [currentGame, setCurrentGame] = useState(null);
  const [onlineUsers, setOnlineUsers] = useState(0);
  const socket = useSocket();

  useEffect(() => {
    socket.on('game-state', (gameState) => {
      setCurrentGame(gameState);
    });

    socket.on('online-users', (count) => {
      setOnlineUsers(count);
    });

    socket.emit('join-spectator');

    return () => {
      socket.off('game-state');
      socket.off('online-users');
    };
  }, [socket]);

  return (
    <div className="home-container">
      <div className="game-status">
        <h1>Canlı Bilgi Yarışması</h1>
        <div className="stats">
          <div className="stat-item">
            <span className="stat-label">Online Oyuncular:</span>
            <span className="stat-value">{onlineUsers}</span>
          </div>
          {currentGame && (
            <div className="stat-item">
              <span className="stat-label">Set Durumu:</span>
              <span className="stat-value">
                {currentGame.currentQuestionIndex + 1}/20
              </span>
            </div>
          )}
        </div>
      </div>

      <div className="preview-container">
        {currentGame ? (
          <>
            <div className="current-question">
              <h2>{currentGame.currentQuestion?.question}</h2>
              <div className="preview-options">
                {currentGame.currentQuestion?.options.map((option, index) => (
                  <div key={index} className="preview-option">
                    {option}
                  </div>
                ))}
              </div>
            </div>
            <div className="timer-preview">
              <div 
                className="timer-bar"
                style={{width: `${(currentGame.timer/900)*100}%`}}
              />
            </div>
          </>
        ) : (
          <div className="no-game">
            <h2>Yeni set yakında başlayacak!</h2>
          </div>
        )}
      </div>

      <button 
        className="join-button"
        onClick={() => setShowLoginModal(true)}
      >
        Yarışmaya Katıl
      </button>

      {showLoginModal && (
        <LoginModal onClose={() => setShowLoginModal(false)} />
      )}
    </div>
  );
}

export default Home; 