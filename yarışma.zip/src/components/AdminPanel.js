import React, { useState, useEffect } from 'react';
import './AdminPanel.css';

function AdminPanel() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    onlineUsers: 0
  });
  const [questions, setQuestions] = useState([]);
  const [newQuestion, setNewQuestion] = useState({
    question: '',
    options: ['', '', '', ''],
    correctAnswer: 0,
    setNumber: 1
  });

  useEffect(() => {
    fetchStats();
    fetchQuestions();
  }, []);

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/stats', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await response.json();
      setStats(data);
    } catch (error) {
      console.error('İstatistikler alınamadı:', error);
    }
  };

  const fetchQuestions = async () => {
    try {
      const response = await fetch('/api/admin/questions', {
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        }
      });
      const data = await response.json();
      setQuestions(data);
    } catch (error) {
      console.error('Sorular alınamadı:', error);
    }
  };

  const handleQuestionSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/admin/questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        body: JSON.stringify(newQuestion)
      });
      
      if (response.ok) {
        setNewQuestion({
          question: '',
          options: ['', '', '', ''],
          correctAnswer: 0,
          setNumber: 1
        });
        fetchQuestions();
      }
    } catch (error) {
      console.error('Soru eklenemedi:', error);
    }
  };

  return (
    <div className="admin-panel">
      <h1>Admin Paneli</h1>
      
      <div className="stats-section">
        <h2>İstatistikler</h2>
        <div className="stats-grid">
          <div className="stat-box">
            <h3>Toplam Kullanıcı</h3>
            <p>{stats.totalUsers}</p>
          </div>
          <div className="stat-box">
            <h3>Online Kullanıcı</h3>
            <p>{stats.onlineUsers}</p>
          </div>
        </div>
      </div>

      <div className="questions-section">
        <h2>Soru Ekle</h2>
        <form onSubmit={handleQuestionSubmit}>
          <div className="form-group">
            <label>Soru</label>
            <input
              type="text"
              value={newQuestion.question}
              onChange={(e) => setNewQuestion({
                ...newQuestion,
                question: e.target.value
              })}
              required
            />
          </div>

          {newQuestion.options.map((option, index) => (
            <div key={index} className="form-group">
              <label>Seçenek {index + 1}</label>
              <input
                type="text"
                value={option}
                onChange={(e) => {
                  const newOptions = [...newQuestion.options];
                  newOptions[index] = e.target.value;
                  setNewQuestion({
                    ...newQuestion,
                    options: newOptions
                  });
                }}
                required
              />
            </div>
          ))}

          <div className="form-group">
            <label>Doğru Cevap (1-4)</label>
            <input
              type="number"
              min="1"
              max="4"
              value={newQuestion.correctAnswer + 1}
              onChange={(e) => setNewQuestion({
                ...newQuestion,
                correctAnswer: parseInt(e.target.value) - 1
              })}
              required
            />
          </div>

          <div className="form-group">
            <label>Set Numarası</label>
            <input
              type="number"
              min="1"
              value={newQuestion.setNumber}
              onChange={(e) => setNewQuestion({
                ...newQuestion,
                setNumber: parseInt(e.target.value)
              })}
              required
            />
          </div>

          <button type="submit" className="submit-button">
            Soru Ekle
          </button>
        </form>
      </div>

      <div className="questions-list">
        <h2>Mevcut Sorular</h2>
        {questions.map((question, index) => (
          <div key={index} className="question-item">
            <h3>{question.question}</h3>
            <div className="options-list">
              {question.options.map((option, optIndex) => (
                <div 
                  key={optIndex} 
                  className={`option ${optIndex === question.correctAnswer ? 'correct' : ''}`}
                >
                  {option}
                </div>
              ))}
            </div>
            <button 
              className="delete-button"
              onClick={() => handleDeleteQuestion(question._id)}
            >
              Sil
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default AdminPanel; 