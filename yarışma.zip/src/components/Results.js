import React, { useEffect, useState } from 'react';
import { useSocket } from '../contexts/SocketContext';
import './Results.css';

function Results() {
  const [scores, setScores] = useState([]);
  const socket = useSocket();

  useEffect(() => {
    socket.on('set-end', (results) => {
      const sortedScores = Object.entries(results)
        .map(([username, score]) => ({ username, score }))
        .sort((a, b) => b.score - a.score);
      setScores(sortedScores);
    });

    return () => {
      socket.off('set-end');
    };
  }, [socket]);

  return (
    <div className="results-container">
      <h1>Set Sonuçları</h1>
      <div className="scores-list">
        {scores.map((score, index) => (
          <div key={index} className={`score-item ${index < 3 ? 'top-three' : ''}`}>
            <span className="rank">{index + 1}</span>
            <span className="username">{score.username}</span>
            <span className="score">{score.score}</span>
          </div>
        ))}
      </div>
      <div className="next-set-timer">
        <p>Yeni set başlıyor...</p>
        <div className="countdown-bar" />
      </div>
    </div>
  );
}

export default Results; 