import React, { useState, useEffect } from 'react';
import { useSocket } from '../contexts/SocketContext';
import './Quiz.css';

function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(null);
  const [timer, setTimer] = useState(900);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [answerResults, setAnswerResults] = useState(null);
  const [streak, setStreak] = useState(0);
  const socket = useSocket();

  useEffect(() => {
    socket.on('question-start', (question) => {
      setCurrentQuestion(question);
      setTimer(900);
      setSelectedAnswer(null);
      setAnswerResults(null);
    });

    socket.on('timer-update', (time) => {
      setTimer(time);
    });

    socket.on('question-results', (results) => {
      setAnswerResults(results);
      // Doğru cevap kontrolü ve streak güncellemesi
      if (results.correctAnswer === selectedAnswer) {
        setStreak(prev => prev + 1);
      } else {
        setStreak(0);
      }
    });

    return () => {
      socket.off('question-start');
      socket.off('timer-update');
      socket.off('question-results');
    };
  }, [socket, selectedAnswer]);

  const handleAnswerSelect = (answerIndex) => {
    if (selectedAnswer === null && timer > 0) {
      setSelectedAnswer(answerIndex);
      socket.emit('submit-answer', {
        answer: answerIndex,
        time: timer
      });
    }
  };

  const calculateBonus = () => {
    if (streak >= 5) return 30;
    if (streak >= 4) return 20;
    if (streak >= 3) return 10;
    return 0;
  };

  return (
    <div className="quiz-container">
      <div className="quiz-header">
        <div className="timer-container">
          <div className="timer-bar" style={{width: `${(timer/900)*100}%`}} />
          <span className="timer-text">{Math.ceil(timer/10)}</span>
        </div>
        <div className="streak-counter">
          <span>Seri: {streak}</span>
          {calculateBonus() > 0 && (
            <span className="bonus">+{calculateBonus()} bonus!</span>
          )}
        </div>
      </div>

      {currentQuestion && (
        <div className="question-section">
          <h2>{currentQuestion.question}</h2>
          <div className="options-container">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(index)}
                className={`option-button ${
                  selectedAnswer === index ? 'selected' : ''
                } ${
                  answerResults && index === currentQuestion.correctAnswer ? 'correct' : ''
                }`}
                disabled={selectedAnswer !== null}
              >
                {option}
                {answerResults && (
                  <span className="answer-count">
                    {answerResults[index]?.count || 0} kişi
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default Quiz; 