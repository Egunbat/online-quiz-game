const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  question: {
    type: String,
    required: true
  },
  options: [{
    type: String,
    required: true
  }],
  correctAnswer: {
    type: Number,
    required: true
  },
  setNumber: {
    type: Number,
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Soruları karıştırmak için helper fonksiyon
questionSchema.statics.getRandomSet = async function(size = 20) {
  const questions = await this.aggregate([
    { $sample: { size } }
  ]);
  return questions;
};

module.exports = mongoose.model('Question', questionSchema); 