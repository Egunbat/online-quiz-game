const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const http = require('http');
const socketIo = require('socket.io');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
require('dotenv').config();

const User = require('./models/User');
const Question = require('./models/Question');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
    methods: ["GET", "POST"]
  }
});

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('MongoDB bağlantısı başarılı');
}).catch((err) => {
  console.error('MongoDB bağlantı hatası:', err);
});

// Game state
let gameState = {
  isActive: false,
  currentSet: null,
  currentQuestionIndex: 0,
  timer: 900,
  answers: {},
  scores: {},
  startTime: null
};

// Yeni set başlatma fonksiyonu
async function startNewSet() {
  try {
    const questions = await Question.getRandomSet(20);
    gameState = {
      isActive: true,
      currentSet: questions,
      currentQuestionIndex: 0,
      timer: 900,
      answers: {},
      scores: {},
      startTime: Date.now()
    };
    io.to('game-room').emit('new-set', gameState);
    startQuestionTimer();
  } catch (error) {
    console.error('Set başlatma hatası:', error);
  }
}

// Soru zamanlayıcısı
function startQuestionTimer() {
  const timer = setInterval(() => {
    gameState.timer -= 1;
    
    if (gameState.timer <= 0) {
      clearInterval(timer);
      handleQuestionEnd();
    } else {
      io.to('game-room').emit('timer-update', gameState.timer);
    }
  }, 100); // 100ms = 1 salise
}

// Soru bitişi
async function handleQuestionEnd() {
  // Sonuçları hesapla ve gönder
  io.to('game-room').emit('question-results', gameState.answers[gameState.currentQuestionIndex]);
  
  // 3 saniye bekle
  await new Promise(resolve => setTimeout(resolve, 3000));
  
  // Sonraki soruya geç
  if (gameState.currentQuestionIndex < 19) {
    gameState.currentQuestionIndex++;
    gameState.timer = 900;
    io.to('game-room').emit('next-question', {
      question: gameState.currentSet[gameState.currentQuestionIndex],
      index: gameState.currentQuestionIndex
    });
    startQuestionTimer();
  } else {
    // Set bitti
    handleSetEnd();
  }
}

// Set bitişi
function handleSetEnd() {
  io.to('game-room').emit('set-end', gameState.scores);
  setTimeout(() => {
    startNewSet();
  }, 10000); // 10 saniye sonra yeni set başlat
}

// Socket bağlantıları
io.on('connection', (socket) => {
  console.log('Yeni bağlantı:', socket.id);

  socket.on('join-game', async (userData) => {
    try {
      const user = await User.findByIdAndUpdate(userData.userId, 
        { isOnline: true, lastActive: new Date() },
        { new: true }
      );

      socket.join('game-room');
      socket.username = user.username;
      socket.userId = user._id;

      socket.emit('game-state', gameState);
      io.emit('online-users', await User.countDocuments({ isOnline: true }));
    } catch (error) {
      console.error('Join game error:', error);
    }
  });

  socket.on('submit-answer', async (data) => {
    if (!gameState.answers[gameState.currentQuestionIndex]) {
      gameState.answers[gameState.currentQuestionIndex] = {};
    }
    
    gameState.answers[gameState.currentQuestionIndex][socket.userId] = {
      answer: data.answer,
      time: data.time
    };
  });

  socket.on('disconnect', async () => {
    if (socket.userId) {
      await User.findByIdAndUpdate(socket.userId, { isOnline: false });
      io.emit('online-users', await User.countDocuments({ isOnline: true }));
    }
  });
});

// Auth middleware
const auth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) {
      return res.status(401).json({ message: 'Token bulunamadı' });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ message: 'Geçersiz kullanıcı' });
    }

    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ message: 'Yetkilendirme hatası' });
  }
};

// API rotaları
app.post('/api/register', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Bu kullanıcı adı zaten kullanılıyor' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ username, password: hashedPassword });
    await user.save();

    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.status(201).json({ token, username: user.username });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

app.post('/api/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(401).json({ message: 'Geçersiz kullanıcı adı veya şifre' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ message: 'Geçersiz kullanıcı adı veya şifre' });
    }

    const token = jwt.sign(
      { userId: user._id },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ token, username: user.username });
  } catch (error) {
    res.status(500).json({ message: 'Sunucu hatası' });
  }
});

// Admin rotaları
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  
  if (username === 'admin' && password === '123321e') {
    const token = jwt.sign({ 
      userId: 'admin',
      isAdmin: true 
    }, process.env.JWT_SECRET);
    
    res.json({ token });
  } else {
    res.status(401).json({ message: 'Geçersiz admin bilgileri' });
  }
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server ${PORT} portunda çalışıyor`);
  
  // İlk seti başlat
  startNewSet();
}); 