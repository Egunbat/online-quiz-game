import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { SocketProvider } from './contexts/SocketContext';
import Home from './components/Home';
import Quiz from './components/Quiz';
import Results from './components/Results';
import AdminPanel from './components/AdminPanel';

function App() {
  return (
    <SocketProvider>
      <Router>
        <div className="App">
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/quiz" component={Quiz} />
            <Route path="/results" component={Results} />
            <Route path="/admin" component={AdminPanel} />
          </Switch>
        </div>
      </Router>
    </SocketProvider>
  );
}

export default App; 